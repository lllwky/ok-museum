// 全局配置文件

module.exports = {
  // 加密解密 token 的密匙
  jwtSecretKey: 'mushuai-_-!',
  // token 有效期
  expiresIn: '1000h'
}