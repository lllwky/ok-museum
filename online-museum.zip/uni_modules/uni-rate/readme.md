

## Rate 评分
> **组件名：uni-rate**
> 代码块： `uRate`
> 关联组件：`uni-icons`


评分组件，多用于购买商品后，对商品进行评价等场景

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-rate)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 